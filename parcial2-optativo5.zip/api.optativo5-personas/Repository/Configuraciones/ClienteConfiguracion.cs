﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using Repository.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Configuraciones;
public class ClienteConfiguracion : IEntityTypeConfiguration<Cliente>
{
    public void Configure(EntityTypeBuilder<Cliente> builder)
    {
        builder
            .HasKey(c => c.Id);

        builder
            .HasMany(cliente => cliente.Facturas)
            .WithOne(factura => factura.Titular)
            .HasForeignKey(factura => factura.Id_cliente);
    }
}
