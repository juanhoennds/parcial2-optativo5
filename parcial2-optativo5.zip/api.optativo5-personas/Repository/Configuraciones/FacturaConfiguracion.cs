﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using Repository.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Configuraciones;

public class FacturaConfiguracion : IEntityTypeConfiguration<Factura>
{
    public void Configure(EntityTypeBuilder<Factura> builder)
    {
        builder
            .HasKey(x => x.Id);

        builder
            .HasOne(factura => factura.Titular)
            .WithMany(cliente => cliente.Facturas)
            .HasForeignKey(factura => factura.Id_cliente);
    }
}
