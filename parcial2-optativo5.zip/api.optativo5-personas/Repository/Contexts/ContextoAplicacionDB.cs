﻿using Microsoft.EntityFrameworkCore;
using Repository.Configuraciones;
using Repository.Entidades;

namespace Repository.Contexts;

//Representa mi BD
public class ContextoAplicacionDB : DbContext
{
    //Representa mi tabla Personas
    public DbSet<Cliente> Clientes { get; set; }
    public DbSet<Factura> Facturas { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfiguration(new ClienteConfiguracion());
        modelBuilder.ApplyConfiguration(new FacturaConfiguracion());

        base.OnModelCreating(modelBuilder);
    }

    public ContextoAplicacionDB(DbContextOptions<ContextoAplicacionDB> options) : base(options)
    {
    }
}
