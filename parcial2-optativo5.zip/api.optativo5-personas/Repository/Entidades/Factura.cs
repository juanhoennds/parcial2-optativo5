﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Entidades
{
    public class Factura
    {
        public int Id { get; set; }
        // Relacion fk
        public string Id_cliente { get; set; } = "";
        public string Nro_factura { get; set; } = "";
        public DateTime Fecha_hora { get; set; }
        public decimal Total { get; set; }
        public decimal Total_iva5 { get; set; }
        public decimal Total_iva10 { get; set; }
        public decimal Total_iva { get; set; }
        public string Total_letras { get; set; } = "";
        public string Sucursal { get; set; } = "";
        //Relacion
        public Cliente Titular { get; set; }
    }
}
