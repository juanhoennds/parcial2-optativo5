﻿using Microsoft.EntityFrameworkCore;
using Repository.Contexts;
using Repository.Entidades;
using Repository.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Repository.Referenciales;
public class ClienteRepository2
{
    private readonly ContextoAplicacionDB _contexto;

    public ClienteRepository2(ContextoAplicacionDB contexto)
    {
        _contexto = contexto;
    }

    public int Agregar(string id_banco, string nombre, string apellido, string documento, string direccion, string mail, string celular, string estado)
    {
        Cliente cliente = new Cliente()
        {
            Id_banco = id_banco,
            Nombre = nombre,
            Apellido = apellido,
            Documento = documento,

        };

        _contexto.Clientes.Add(cliente);

        int resultado = _contexto.SaveChanges(); //recien aqui impacto en la BD.

        return resultado;
    }

    public ClienteConFacturas ObtenerPorId(int id)
    {
        //var persona = _contexto.Personas.Find(id);

        var cliente = _contexto.Clientes
            .Include(cliente => cliente.Facturas)
            .FirstOrDefault(cliente => cliente.Id == id);

        if (cliente == null)
        {
            throw new Exception("No se encontro al cliente con el id solicitado");
        }

        //Transformar de entidad a modelo
        var clienteConFacturas= new ClienteConFacturas()
        {
            Id = cliente.Id,
            Nombre = cliente.Nombre,
            Apellido = cliente.Apellido,
            Documento = cliente.Documento,
            Direccion = cliente.Direccion,
            Mail = cliente.Mail,
            Celular = cliente.Celular,
            Estado = cliente.Estado,
            Facturas = cliente.Facturas.Select(factura => new FacturaModelo
            {
                Id = factura.Id,
                Id_cliente = factura.Id_cliente,
                Nro_factura = factura.Nro_factura,
                Fecha_hora = factura.Fecha_hora,
                Total = factura.Total,
                Total_iva5 = factura.Total_iva5,
                Total_iva10 = factura.Total_iva10,
                Total_iva = factura.Total_iva10,
                Total_letras = factura.Total_letras,
                Sucursal = factura.Sucursal,
            }).ToList()
        };

        return clienteConFacturas;
    }

    public Cliente Actualizar(int id, string nombre)
    {
        var cliente = _contexto.Clientes.Find(id);

        if (cliente == null)
        {
            throw new Exception("No se encontro al cliente con el id solicitado");
        }

        cliente.Nombre = nombre;

        _contexto.SaveChanges();

        return cliente;
    }

    public string Eliminar(int id)
    {
        var cliente = _contexto.Clientes.Find(id);

        if (cliente == null)
        {
            throw new Exception("No se encontro al cliente con el id solicitado");
        }

        _contexto.Clientes.Remove(cliente);

        _contexto.SaveChanges();

        return "Eliminado exitosamente";
    }
}
