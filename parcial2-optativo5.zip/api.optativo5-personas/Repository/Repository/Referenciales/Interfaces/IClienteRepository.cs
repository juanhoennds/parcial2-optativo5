﻿using Repository.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Repository.Referenciales.Interfaces
{
    public interface IClienteRepository
    {
        void add(ClienteModelo cliente);
        ClienteModelo get(int id);
        IEnumerable<ClienteModelo> getAll();
        void update(ClienteModelo cliente);
    }
}
