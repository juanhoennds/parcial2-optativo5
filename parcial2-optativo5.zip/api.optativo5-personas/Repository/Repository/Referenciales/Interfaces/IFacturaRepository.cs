﻿using Repository.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Repository.Referenciales.Interfaces
{
    public interface IFacturaRepository
    {
        void add(FacturaModelo factura);
        FacturaModelo get(int id);
        IEnumerable<FacturaModelo> getAll();
        void update(FacturaModelo factura);
    }
}
