﻿using Repository.Contexts;
using Repository.Entidades;
using Microsoft.EntityFrameworkCore;
using Repository.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.Repository.Referenciales;

public class FacturaRepository2
{
    private readonly ContextoAplicacionDB _contexto;

    public FacturaRepository2(ContextoAplicacionDB contexto)
    {
        _contexto = contexto;
    }

    public int Agregar(string id_cliente, string nro_factura, DateTime fecha_hora, decimal total, decimal total_iva5, decimal total_iva10, decimal total_iva, string total_letras, string sucursal)
    {
        Factura factura = new Factura()
        {
            Id_cliente = id_cliente,
            Nro_factura = nro_factura,
            Fecha_hora = fecha_hora,
            Total = total,
            Total_iva5 = total_iva5,
            Total_iva10 = total_iva10,
            Total_iva = total_iva,
            Total_letras = total_letras,
            Sucursal = sucursal
        };

        _contexto.Facturas.Add(factura);

        int resultado = _contexto.SaveChanges(); //recien aqui impacto en la BD.

        return resultado;
    }

    public Factura Actualizar(int id, string nro_factura)
    {
        var factura = _contexto.Facturas.Find(id);

        if (factura == null)
        {
            throw new Exception("No se encontro la factura con el id solicitado");
        }

        factura.Nro_factura = nro_factura;

        _contexto.SaveChanges();

        return factura;
    }

    public string Eliminar(int id)
    {
        var factura = _contexto.Facturas.Find(id);

        if (factura == null)
        {
            throw new Exception("No se encontro al cliente con el id solicitado");
        }

        _contexto.Facturas.Remove(factura);

        _contexto.SaveChanges();

        return "Eliminado exitosamente";
    }
}
