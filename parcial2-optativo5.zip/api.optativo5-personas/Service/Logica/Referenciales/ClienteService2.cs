﻿using Repository.Contexts;
using Repository.Entidades;
using Repository.Models;
using Repository.Repository.Referenciales;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service.Logica.Referenciales;

public class ClienteService2
{
    private readonly ClienteRepository2 _repository;

    public ClienteService2(ContextoAplicacionDB contexto)
    {
        _repository = new ClienteRepository2(contexto);
    }

    public int Agregar(string id_banco, string nombre, string apellido, string documento, string direccion, string mail, string celular, string estado)
    {
        return _repository.Agregar(id_banco, nombre, apellido, documento, direccion, mail, celular, estado);
    }

    public ClienteConFacturas ObtenerPorId(int id)
    {
        return _repository.ObtenerPorId(id);
    }

    public Cliente Actualizar(int id, string nombre)
    {
        return _repository.Actualizar(id, nombre);
    }

    public string Eliminar(int id)
    {
        return _repository.Eliminar(id);
    }
}