﻿using Repository.Contexts;
using Repository.Entidades;
using Repository.Models;
using Repository.Repository.Referenciales;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Service.Logica.Referenciales;

public class FacturaService2
{
    private readonly FacturaRepository2 _repository;

    public FacturaService2(ContextoAplicacionDB contexto)
    {
        _repository = new FacturaRepository2(contexto);
    }

    public int Agregar(int id_cliente, string nro_factura, DateTime fecha_hora, decimal total, decimal total_iva5, decimal total_iva10, decimal total_iva, string total_letras, string sucursal)
    {
        // Validación de Nro. Factura
        if (!Regex.IsMatch(nro_factura, @"^\d{3}-\d{3}-\d{6}$"))
        {
            throw new ArgumentException("El número de factura no cumple con el patrón establecido");
        }

        // Validación de Total, Total_iva5, Total_iva10, Total_iva
        if (total <= 0 || total_iva5 <= 0 || total_iva10 <= 0 || total_iva <= 0)
        {
            throw new ArgumentException("Los totales deben ser números positivos");
        }

        // Validación de Total en letras
        if (string.IsNullOrWhiteSpace(total_letras) || total_letras.Length < 6)
        {
            throw new ArgumentException("El total en letras debe tener al menos 6 caracteres");
        }

        // Si todas las validaciones pasan, agregar la factura
        return _repository.Agregar(id_cliente, nro_factura, fecha_hora, total, total_iva5, total_iva10, total_iva, total_letras, sucursal);
    }

    public Factura Actualizar(int id, string nro_factura)
    {
        return _repository.Actualizar(id, nro_factura);
    }

    public string Eliminar(int id)
    {
        return _repository.Eliminar(id);
    }
}