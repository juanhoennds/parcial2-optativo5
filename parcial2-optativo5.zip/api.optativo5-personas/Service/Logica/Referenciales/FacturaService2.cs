﻿using Repository.Contexts;
using Repository.Entidades;
using Repository.Models;
using Repository.Repository.Referenciales;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service.Logica.Referenciales;

public class FacturaService2
{
    private readonly FacturaRepository2 _repository;

    public FacturaService2(ContextoAplicacionDB contexto)
    {
        _repository = new FacturaRepository2(contexto);
    }

    public int Agregar(string id_cliente, string nro_factura, DateTime fecha_hora, decimal total, decimal total_iva5, decimal total_iva10, decimal total_iva, string total_letras, string sucursal)
    {
        return _repository.Agregar(id_cliente, nro_factura, fecha_hora, total, total_iva5, total_iva10, total_iva, total_letras, sucursal);
    }
    public Factura Actualizar(int id, string nro_factura)
    {
        return _repository.Actualizar(id, nro_factura);
    }

    public string Eliminar(int id)
    {
        return _repository.Eliminar(id);
    }
}