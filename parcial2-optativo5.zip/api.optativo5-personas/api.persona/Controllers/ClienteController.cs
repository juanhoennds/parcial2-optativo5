﻿using Microsoft.AspNetCore.Mvc;
using Repository.Contexts;
using Repository.Entidades;
using Repository.Models;
using Service.Logica.Referenciales;

namespace api.persona.Controllers
{
    [Route("api/v1/[controller]")]
    public class ClienteController : Controller
    {
        //private PersonaService personaService;
        private ClienteService2 clienteService2;

        public ClienteController(IConfiguration configuracion, ContextoAplicacionDB contexto)
        {
            //personaService = new PersonaService(configuracion.GetConnectionString("postgresConnection"));
            clienteService2 = new ClienteService2(contexto);
        }
        /*[HttpPost]
        public ActionResult add([FromBody] PersonaModel persona)
        {
            personaService.add(persona);
            return Ok(new { message = "Registro insertado Correctamente" });
        }*/

        [HttpPost("entity-framework")]
        public ActionResult AgregarConEntity([FromBody] Cliente cliente)
        {
            int resultado = clienteService2.Agregar(cliente.Id_banco, cliente.Nombre, cliente.Apellido, cliente.Documento, cliente.Direccion, cliente.Mail, cliente.Celular, cliente.Estado);
            return Ok(resultado);
        }

        [HttpGet("{id}")]
        public ActionResult ObtenerPorId([FromRoute] int id)
        {
            var resultado = clienteService2.ObtenerPorId(id);
            return Ok(resultado);
        }

        [HttpPut("{id}")]
        public ActionResult Actualizar([FromRoute] int id, [FromBody] string nombre)
        {
            var resultado = clienteService2.Actualizar(id, nombre);
            return Ok(resultado);
        }

        [HttpDelete("{id}")]
        public ActionResult Eliminar([FromRoute] int id)
        {
            var resultado = clienteService2.Eliminar(id);
            return Ok(resultado);
        }
    }
}
