﻿using Microsoft.AspNetCore.Mvc;
using Repository.Contexts;
using Repository.Entidades;
using Repository.Models;
using Service.Logica.Referenciales;

namespace api.persona.Controllers
{
    [Route("api/v1/[controller]")]
    public class FacturaController : Controller
    {
        //private PersonaService personaService;
        private FacturaService2 facturaService2;

        public FacturaController(IConfiguration configuracion, ContextoAplicacionDB contexto)
        {
            //personaService = new PersonaService(configuracion.GetConnectionString("postgresConnection"));
            facturaService2 = new FacturaService2(contexto);
        }
        /*[HttpPost]
        public ActionResult add([FromBody] PersonaModel persona)
        {
            personaService.add(persona);
            return Ok(new { message = "Registro insertado Correctamente" });
        }*/

        [HttpPost("entity-framework")]
        public ActionResult AgregarConEntity([FromBody] Factura factura)
        {
            int resultado = facturaService2.Agregar(factura.Id_cliente, factura.Nro_factura, factura.Fecha_hora, factura.Total, factura.Total_iva5, factura.Total_iva10, factura.Total_iva, factura.Total_letras, factura.Sucursal);
            return Ok(resultado);
        }

        [HttpGet("{id}")]
        /*public ActionResult ObtenerPorId([FromRoute] int id)
        {
            var resultado = clienteService2.ObtenerPorId(id);
            return Ok(resultado);
        }*/

        [HttpPut("{id}")]
        public ActionResult Actualizar([FromRoute] int id, [FromBody] string nro_factura)
        {
            var resultado = facturaService2.Actualizar(id, nro_factura);
            return Ok(resultado);
        }

        [HttpDelete("{id}")]
        public ActionResult Eliminar([FromRoute] int id)
        {
            var resultado = facturaService2.Eliminar(id);
            return Ok(resultado);
        }
    }
}